import pygame
import os
import random 

pygame.init()

# seting the  Display size
display_width = 740
display_height = 490

# loading the Background image
bg = pygame.image.load(os.path.join("dmc5stuff", "pixel-art-mystical-background.webp"))

gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption('vurgil')

# Defining colors for the game screen 
black = (0, 0, 0)
white = (255, 255, 255)

clock = pygame.time.Clock()
crashed = False

# Loading the diffrent spright images 
vieImg1 = pygame.image.load(os.path.join("dmc5stuff", "Vergilall.png"))
vieImg2 = pygame.image.load(os.path.join("dmc5stuff", "Vergilpu.png"))
vieImg3 = pygame.image.load(os.path.join("dmc5stuff", "Vergilattack.png"))
vieImg4 = pygame.image.load(os.path.join("dmc5stuff", "Vergildefens.png"))

danImg1 = pygame.image.load(os.path.join("dmc5stuff", "danteall.png"))
danImg2 = pygame.image.load(os.path.join("dmc5stuff", "dantegun.png"))
danImg3 = pygame.image.load(os.path.join("dmc5stuff", "dantehat.png"))
danImg4 = pygame.image.load(os.path.join("dmc5stuff", "dantepu.png"))

# Function to display images on screen
def display_image(image, x, y):
    gameDisplay.blit(image, (x, y))

# Image positions
vig_x = 0
vig_y = 180
dan_x = 400
dan_y = 160

while not crashed:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            crashed = True

    gameDisplay.blit(bg, (0, 0))

    keys = pygame.key.get_pressed()

    # Checking which keys are pressed and displaying the corresponding images
    if keys[pygame.K_1]:
        display_image(vieImg1, vig_x, vig_y)
        display_image(danImg1, dan_x, dan_y)
    
    if keys[pygame.K_2]:
        display_image(vieImg2, vig_x, vig_y)
    
    if keys[pygame.K_3]:
        display_image(vieImg3, vig_x, vig_y)
    
    if keys[pygame.K_4]:
        display_image(vieImg4, vig_x, vig_y)
    
    if keys[pygame.K_0]:
        display_image(danImg1, dan_x, dan_y)
    
    if keys[pygame.K_9]:
        display_image(danImg2, dan_x, dan_y)
    
    if keys[pygame.K_8]:
        display_image(danImg3, dan_x, dan_y)
    
    if keys[pygame.K_7]:
        display_image(danImg4, dan_x, dan_y)

    if keys[pygame.K_ESCAPE]:
        crashed = True
        pygame.quit()

    pygame.display.update()



# Define the game options
game_options = ['rock', 'paper', 'scissors']

# Define the ASCII art for each option
rock_art = """
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
"""

paper_art = """
     _______
---'    ____)____
           ______)
          _______)
         _______)
---.__________)
"""

scissors_art = """
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
"""

# Store the ASCII art for each option in a dictionary
ascii_art = {'rock': rock_art, 'paper': paper_art, 'scissors': scissors_art}

# Define the function to play the game
def play_game():
    # Get the player's choice
    player_choice = input("Choose rock, paper, or scissors: ")
    
    # Check if the player's choice is valid
    if player_choice not in game_options:
        print("Invalid choice.")
        return
    
    # Get the computer's choice
    computer_choice = random.choice(game_options)
    
    # Display the choices
    print(f"\nYou chose {player_choice}:")
    print(ascii_art[player_choice])
    print(f"\nThe computer chose {computer_choice}:")
    print(ascii_art[computer_choice])
    
    # Determine the winner
    if player_choice == computer_choice:
        print("It's a tie!")
    elif player_choice == 'rock' and computer_choice == 'scissors':
        print("You win!")
    elif player_choice == 'paper' and computer_choice == 'rock':
        print("You win!")
    elif player_choice == 'scissors' and computer_choice == 'paper':
        print("You win!")
    else:
        print("You lose!")
        
# Play the game
play_game()

#INSIDE OF THE GAME LOOP


#REST OF ITEMS ARE BLIT'D TO SCR
pygame.quit()
quit()


